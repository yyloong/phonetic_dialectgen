.. _contrib:

contrib
========

.. _tone_convert:

拼音转换
--------

.. autofunction:: pypinyin.contrib.tone_convert.to_normal
.. autofunction:: pypinyin.contrib.tone_convert.to_tone
.. autofunction:: pypinyin.contrib.tone_convert.to_tone2
.. autofunction:: pypinyin.contrib.tone_convert.to_tone3
.. autofunction:: pypinyin.contrib.tone_convert.to_initials
.. autofunction:: pypinyin.contrib.tone_convert.to_finals
.. autofunction:: pypinyin.contrib.tone_convert.to_finals_tone
.. autofunction:: pypinyin.contrib.tone_convert.to_finals_tone2
.. autofunction:: pypinyin.contrib.tone_convert.to_finals_tone3
