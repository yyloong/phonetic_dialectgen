# -*- coding: utf-8 -*-
"""最大正向匹配分词"""

# 用于向后兼容，TODO: 废弃
from pypinyin.seg.mmseg import Seg, PrefixSet, seg, retrain, p_set  # noqa
